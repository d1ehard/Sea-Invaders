// player controlled
var sprites = []; // this is an array (not the square brackets)
var score = 0;
var playerTeam = 1;
var enemyTeam = 2;
var gameOver = false;

function newGame() {
    score = 0;    
    sprites = [];
    for (var i = 0; i < 10; i++) {
        sprites.push(new Enemy(random(width), random(-500, 0), enemyTeam));
    }
    // plus the player
    sprites.push(new Ship(playerTeam));
}

function setup() {
    createCanvas(450, 400);
    newGame();
}

function draw() {
    background(0);
    if (gameOver) {
        background(0);
        textSize(56);
        textAlign(CENTER);
        fill(255);
        text("Game Over", width / 2, height / 3);
        text(score, width / 2, height / 2);
        text("Press Space", width/2, 2 * height/3);
    } else {
        // score in white
        fill(255);
        textSize(18);
        strokeWeight(1);
        text(score, 50, 50);
        // nested loops
        for (var i = 0; i < sprites.length; i++) {
            sprites[i].display();
            sprites[i].control();
            for (var j = 0; j < sprites.length; j++) {
                if (sprites[i] && sprites[j]) {
                    if (sprites[i].team !== sprites[j].team && sprites[i].isColliding(sprites[j])) {
                        sprites[j].handleCollision();
                        sprites[i].handleCollision();
                    }
                }
            }
        }
    }
}

function keyPressed() {
    if (key == ' ' && gameOver) {
        gameOver = false;
        newGame();
    }
}